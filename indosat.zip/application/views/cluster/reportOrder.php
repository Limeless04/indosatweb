<?=$this->session->flashdata('notif');?>
<?=$this->session->flashdata('masuk');?>
    <div class="container">
    <h3>Report Progress</h3>
            <p>Pesanan Progress > 5 hari</p>
            <table id="reportTable-progress" width="100%">
            <thead>
                <tr>
                <th>Nama Pelanggan</th>
                <th>No WA</th>
                <th>Alamat</th>
                <th>Produk</th>
                <th>MSISDN</th>
                <th>Cluster</th>
                <th>Status</th>
                <th>Tgl Dibuat</th>
                <th>Aksi</th>
                </tr>
            </thead>
            </table>
            <h3>Report Sheet</h3>
            <table id="reportTable" width="100%">
            <thead>
                <tr>
                <th>Nama Pelanggan</th>
                <th>No WA</th>
                <th>Alamat</th>
                <th>Produk</th>
                <th>MSISDN</th>
                <th>Cluster</th>
                <th>Status</th>
                <th>Tgl Dibuat</th>
                <th>Aksi</th>
                </tr>
            </thead>
            </table>
            </div>