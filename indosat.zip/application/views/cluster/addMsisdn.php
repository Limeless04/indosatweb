<h3 class="header_beli">Tambah Msisdn Baru</h3>
<div class="crud_msisdn">  
<form action="" method="post">
    <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Msisdn</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" id="msisdn" name="msisdn" value="<?= set_value('msisdn');?>">
        </div>
    </div>
        <button type="submit" class="btn" id="btn_submit">Submit</button>
    </form>
</div> 