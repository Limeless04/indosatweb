    <div class="container">
    <img src="<?= base_url('assets/');?>img/landing_page.png" id="landing_page" alt="">
    <ul class="land_ul">
        <li class="land_li"><a class="btn_beli" href="<?= base_url("Beli/");?>">Beli Sekarang</a></li>
        <li class="land_li"><a class="btn_claim" href="#">Claim Hadiah</a></li>
    </ul>
    </div>
