<div class="container">
<h1>Pembelian Sukses</h1>
<p>Silahkan Melanjutkan proses transaksinya</p>
</div>
