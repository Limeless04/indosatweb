<h1><?php echo $heading; ?></h1>

<table id="table-report">
<thead>
  <tr>
    <th>Cluster</th>
    <th>Order</th>
    <th>Sukses</th> 
    <th>Reject</th>
    <th>Progress</th>
  </tr>
</thead>
</table>
