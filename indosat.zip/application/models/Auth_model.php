<?php
class Auth_model extends CI_model{
}